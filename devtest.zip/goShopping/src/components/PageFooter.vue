<template>
  <div class="bg-gradient-to-br relative from-slate-700 via-blue-600 opacity-3 to-slate-800">
      <div class="op">
        <div class="flex justify-evenly">
          <div class=" py-10">
            <h1 class="text-2xl font-source font-bold text-white mb-3"><span class="text-blue-200">Go</span>Shopping</h1>
          <div class="mt-2 space-y-2">
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">PO box 11683. street west victoria crest Australia</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Phone: (+234) 70165-88973</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Email:beritogwu@gmail.com</p>
            </div>
          </div>
          </div>
          <div class=" py-10">
            <h1 class="text-xl font-source font-bold text-white mb-3">Quicklinks</h1>
          <div class="mt-2 space-y-2">
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">NFt market place</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">BuzzSchool.io</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Crypto.io</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
              </span>
              <router-link :to="{name: 'Affiliates'}" class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Become an affiliate</router-link>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Privacy and policy</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Terms and conditions</p>
              <!-- <span class="las la-link"></span> -->
            </div>
          </div>
          </div>
          <div class=" py-10">
            <h1 class="text-xl font-source font-bold text-white mb-3">Shared Services</h1>
          <div class="mt-2 space-y-2">
            <div class="flex items-center">
              <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clip-rule="evenodd" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Digital marketing</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" viewBox="0 0 20 20" fill="currentColor">
                  <path fill-rule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clip-rule="evenodd" />
                </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Copywriting</p>
            </div>
            <div class="flex items-center">
              <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clip-rule="evenodd" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Quality resources</p>
            </div>
            <div class="flex items-center">
              <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 text-white w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clip-rule="evenodd" />
              </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Product advertisement</p>
            </div>
            
            
          </div>
          </div>
          <div class=" py-10">
            <h1 class="text-xl font-source font-bold text-white mb-3">Recent blogs</h1>
          <div class="mt-2 space-y-2">
            <div class="flex items-center">
              <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor">
              <path d="M5 3a1 1 0 000 2c5.523 0 10 4.477 10 10a1 1 0 102 0C17 8.373 11.627 3 5 3z" />
              <path d="M4 9a1 1 0 011-1 7 7 0 017 7 1 1 0 11-2 0 5 5 0 00-5-5 1 1 0 01-1-1zM3 15a2 2 0 114 0 2 2 0 01-4 0z" />
            </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">How to make money from full time business career</p>
            </div>
            <div class="flex items-center">
              <span>
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor">
              <path d="M5 3a1 1 0 000 2c5.523 0 10 4.477 10 10a1 1 0 102 0C17 8.373 11.627 3 5 3z" />
              <path d="M4 9a1 1 0 011-1 7 7 0 017 7 1 1 0 11-2 0 5 5 0 00-5-5 1 1 0 01-1-1zM3 15a2 2 0 114 0 2 2 0 01-4 0z" />
            </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Make good use of goShopping business tools</p>
            </div>
            <div class="flex items-center">
              <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor">
              <path d="M5 3a1 1 0 000 2c5.523 0 10 4.477 10 10a1 1 0 102 0C17 8.373 11.627 3 5 3z" />
              <path d="M4 9a1 1 0 011-1 7 7 0 017 7 1 1 0 11-2 0 5 5 0 00-5-5 1 1 0 01-1-1zM3 15a2 2 0 114 0 2 2 0 01-4 0z" />
            </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">The fun fair of making a well balansable thought</p>
            </div>
            <div class="flex items-center">
              <span>
              <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor">
              <path d="M5 3a1 1 0 000 2c5.523 0 10 4.477 10 10a1 1 0 102 0C17 8.373 11.627 3 5 3z" />
              <path d="M4 9a1 1 0 011-1 7 7 0 017 7 1 1 0 11-2 0 5 5 0 00-5-5 1 1 0 01-1-1zM3 15a2 2 0 114 0 2 2 0 01-4 0z" />
            </svg>
              </span>
              <p class="text-[0.79rem] leading-[1] ml-2 text-blue-200 font-source">Setting up your businness in a well publishable manner</p>
            </div>
            
            
          </div>
          </div>
          
        </div>
        <div style="background-color:rgba(0,0,0,0.5)" class="py-3">
          <div class="flex justify-evenly text-blue-300 font-source">
            <div>goShopping {{ new Date().getFullYear() }} @ all right reserved</div>
            <div class="text-white font-oleo text-lg">Powered by intech tech solutions</div>
            <div class="space-x-3">
              <span style="background-color:rgba(0,0,0,0.6)" class=" px-1 py-0.5 rounded-full"><i class="lab text-sm la-facebook-f"></i></span>
              <span style="background-color:rgba(0,0,0,0.6)" class=" px-1 py-0.5 rounded-full"><i class="lab la-twitter"></i></span>
              <span style="background-color:rgba(0,0,0,0.6)" class=" px-1 py-0.5 rounded-full"><i class="lab la-instagram"></i></span>
            </div>
          </div>
        </div>
      </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>