<template>
  <div>
      <div class=" bg-gradient-to-br from-blue-50 via-blue-200 to-gray-50 py-[5rem]">
          <div class="flex justify-center items-center">
              <div class="w-1/2">
                  <h1 class="uppercase  text-gray-700 text-3xl font-bold font-signika animate-fade-side-right">Earn money with the goShopping Affiliate Program by PROMOTING HIGH QUALITY PRODUCTS</h1>
                <p class="mt-6 text-xl text-gray-700 font-source">Refer visitors to goShopping and earn 63% of the customer’s first monthly payment or $870 per enterprise customer. Join today to grow your revenue with the leading ecommerce platform.</p>
                <p class="mt-6 font-bold font-source">It's simple and quick to get started.</p>
              </div>
              <div>
                  <!-- <img src="../assets/icons/man.png" class="object-cover opacity-60 h-[30rem] w-[38rem]" alt=""> -->
              </div>
          </div>
          <div class="flex space-x-6 items-center justify-center mt-8">      
                <router-link :to="{name: 'AffiliateRegister'}" class="group ">
                  <div class="h-12  flex justify-center items-center">
                      <span class="group-hover:text-purple-600 font-source tracking-wider font-bold">APPLY NOW</span>
                      <span>
                          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 group-hover:animate-fade-in-up text-purple-600 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                            </svg>
                      </span>
                  </div>
              </router-link>
                <a href="" class="group">
                  <div class="h-12  flex justify-center px-6 space-x-1 hover:ring-blue-300 hover:ring hover:ring-offset-2 bg-blue-700 rounded-md items-center">
                      <span class="text-white font-source font-bold">Request a demo account</span>
                      <span>
                          <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-white" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 2a5 5 0 00-5 5v2a2 2 0 00-2 2v5a2 2 0 002 2h10a2 2 0 002-2v-5a2 2 0 00-2-2H7V7a3 3 0 015.905-.75 1 1 0 001.937-.5A5.002 5.002 0 0010 2z" />
                        </svg>
                      </span>
                  </div>
              </a>
          </div>
          
          <div>
              
          </div>
      </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>