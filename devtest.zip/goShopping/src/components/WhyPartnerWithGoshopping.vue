<template>
  <div class="bg-blue-50 py-12 px-9 antialiased font-source">
      <div class="flex">
        <div class="w-1/2 divide-y-[0.2rem] space-y-4 px-8 divide-purple-600">
          <h1 class="text-4xl text-gray-700 font-signika font-extrabold">Why partner with GoShopping?</h1>
          <div class="py-3">
            <h1 class="text-2xl font-medium">Promotion made easy</h1>
            <p>
              Promote BigCommerce anywhere via our referral link, or use our pre-made banners, emails and more. 
              Save time and money on content creation by linking to blogs, webinars and more with content developed 
              by BigCommerce for your audience.
            </p>
          </div>
          <div class="py-3">
            <h1 class="text-2xl font-medium">Powerful tracking system</h1>
            <p>
              Our affiliate dashboard offers a comprehensive look at your clicks, trials, sales and commissions. 
              You can view your earnings, track performance, and will get paid at the same time every month.
            </p>
          </div>
          <div class="py-3">
            <h1 class="text-2xl font-medium">A dedicated account manager</h1>
            <p>
              Our affiliate dashboard offers a comprehensive look at your clicks, trials, sales and commissions. You can view your earnings, 
              track performance, and will get paid at the same time every month.
            </p>
          </div>
        </div>
        <div>
          <img src="../assets/icons/moneymaking.png" class="object-contain h-[30rem] w-[30rem]" alt="">
        </div>
      </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>