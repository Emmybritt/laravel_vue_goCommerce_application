<template>
  <div class="bg-slate-100 px-[12rem] py-12">
      <div class="grid grid-cols-4">
          <div>
              Crafted by Mintech
          </div>
          <div>
              <h1 class="font-signika text-lg font-bold">GoComerce</h1>
              <ul class="text-sm mt-3 space-y-2">
                  <li><a href="#">Pricing</a></li>
                  <li><a href="#">Status</a></li>
                  <li><a href="#">ChangeLog</a></li>
                  <li><a href="#">Terms and condition</a></li>
                  <li><a href="#">Privacy and policy</a></li>
              </ul>
          </div>
          
          <div>
              <h1 class="font-signika text-lg font-bold">Mintech E<i>x</i>perience</h1>
              <ul class="text-sm mt-3 space-y-2">
                  <li><a href="#">Mintech blogs</a></li>
                  <li><a href="#">BuzzSchool.io</a></li>
                  <li><a href="#">Smart checklist</a></li>
              </ul>
          </div>
          <div>
              <h1 class="font-signika text-lg font-bold">Contact</h1>
              <ul class="text-sm mt-3 space-y-2">
                  <li>
                      <div>
                          <span><b>Email: </b></span>
                          <a href="mailto:support@gocommerce.com">support@gocommerce.com</a>
                      </div>
                  </li> 
                  <li>
                      <div class="flex justify-start space-x-2">
                          <a href="#" class=" px-2 py-2 rounded-full bg-purple-600 text-white"><i class="text-center lab  la-facebook-f text-2xl"></i></a>
                          <a href="#" class=" px-2 py-2 rounded-full bg-purple-600 text-white"><i class="text-center lab la-twitter text-2xl"></i></a>
                          <a href="#" class=" px-2 py-2 rounded-full bg-purple-600 text-white"><i class="text-center lab la-instagram text-2xl"></i></a>
                      </div>
                </li>                     
              </ul>
          </div>
      </div>
      <div class="flex mt-[4rem]">
          <div class="w-1/3 flex flex-end">
              <h1 class="text-sm font-bold font-signika">© Mintech Products, Inc.</h1>
          </div>
          <div class="w-2/3">
              <h1 class="text-lg font-sign">What is GoComerce?.</h1>
              <p class="text-gray-600 text-sm mt-3">
                  GoCommerce is a Plartform mail server solution that allows testing email notifications without sending 
                  them to the real users of your application. Not only does Mailtrap work as a powerful email test 
                  tool, it also lets you view your dummy emails online, forward them to your regular mailbox, share with the team and more! Mailtrap is a mail server test tool built by Railsware Products, Inc., a premium software development consulting company.
              </p>
          </div>
      </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>