<template>
  <div>
      <div class="mb-1">
          <div class="flex items-center py-6 bg-gradient-to-r py-6 from-slate-800 px-[6rem] space-x-3 via-purple-900 to-purple-700">
              <div class="w-1/2">
                  <h1 class="text-white text-2xl font-bold">
                      We’ve got more coming...
                  </h1>
                  <p class="text-purple-200 leading-snug mt-2 text-lg">Want to hear from us occasionally with Goshopping news? 
            Sign up for our newsletter and we'll email you every time we release a new updates.</p>
              </div>
              <div>
                  <form action="" class="flex items-center">
                      <div class="w-full">
                          <input type="text" class="w-[30rem] text-purple-100 border-none outline-none px-4 py-3 rounded-full" style="background-color:rgba(0,0,0,0.2)" placeholder="Enter your name">
                      </div>
                      <div class="w-full">
                          <button class="px-3 py-2 rounded-md text-white bg-slate-900 ml-1">Subscribe</button>
                      </div>                      
                  </form>
              </div>
          </div>
      </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>