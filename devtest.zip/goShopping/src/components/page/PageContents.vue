<template>
  <div class="bg-gradient-to-tr font-source from-pink-100 vian-pink-100 ">
      <!-- Not intricacy section -->
      <div style="padding: 50px 0;" class="flex justify-center flex-col h-[20rem] items-center text-gray-700">
          <h1 class="text-4xl font-semibold">Not Intricacy, but Advancement</h1>
          <p class="mt-3 md:w-[50rem] md:text-center text-xl">Meet the world's most versatile and open ecommerce platform, ushering in a new ecommerce era. 
              Explore endless possibilities for building, innovating, and growing your business.</p>
      </div>
      <!-- Not intricacy section ends here -->
      <div class="bg-gradient-to-r from-white via-gray-50 to-gray-100">
          <!-- Build section starts here -->
      <div style="">
          <div class="flex justify-between px-12">
            <div class="w-1/2 pl-12 pt-9">
            <div class="flex flex-col">
                <div>
                    <h1 class="text-5xl font-extrabold">Build</h1>
                <p class="text-xl font-roboto my-6">Start with the rock-solid foundation of a powerful ecommerce platform.</p>
                </div>
                <div>
                    <article class="prose-xl mt-4 text-gray-600 leading-snug font-bold">
                    “We presumed GoShopping had a stronger influence on business owners than other platforms in terms of developing capabilities such as headless commerce connectors, open vendor storefronts, technical assistance, and multi-currency support.”
                </article>
                </div>
                <p class="mt-4 font-signika"><b>Medicalthron:</b> Ecomerce and Business consultant</p>
            </div>
                
                
            </div>
            <div class="w-1/2">
                <img src="../../assets/icons/develop.jpg" alt="" class="h-[25rem] object-fill float-right w-[30rem]">
            </div>
          </div>
      </div>
      <!-- Build section ends here -->
      <!-- Features section starts here -->
      <div style="" class="bg-white px-[6rem] py-12">
         <div class="grid grid-cols-4 gap-3">
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/design.png" class="h-12 w-12" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Design with freedom</h1>
                     <p class="text-gray-600">Spark creativity and craft beautiful store experiences with design tools that know no bounds.</p>
                 </div>
             </div>
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/padlock.png" class="h-[3.4rem] w-[3.4rem]" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Operate without Worry</h1>
                     <p class="text-gray-600">Tame operational complexity with an easy-to-use, secure platform that's up when you need it most..</p>
                 </div>
             </div>
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/metre.png" class="h-[3.4rem] w-[3.4rem]" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Outperform the Competition</h1>
                     <p class="text-gray-600">Deliver lightning-fast commerce experiences that keep your customers coming back for more.</p>
                 </div>
             </div>
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/sonu.png" class="h-[3.4rem] w-[3.4rem]" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Feature-Rich Platform</h1>
                     <p class="text-gray-600">How LARQ is growing its sustainable business with BigCommerce.</p>
                 </div>
             </div>
            </div>
      </div>
      </div>
      
      <div class="px-12">
          <hr>
      </div>
      
      <!-- Features section ends here -->

      <!-- Another section starts here -->
      <div>
          <!-- Build section starts here -->
      <div style="" class="bg-gradient-to-r from-white via-gray-50 to-gray-100 py-12">
          <div class="flex justify-between px-12">
              <div class="w-1/2">
                <img src="../../assets/icons/lady.png" alt="" class="h-[25rem] object-fill float-left w-[30rem]">
            </div>
            <div class="w-1/2 pt-9">
            <div class="flex flex-col">
                <div>
                    <h1 class="text-5xl font-extrabold">Innovate</h1>
                <p class="text-xl font-roboto my-6">Turn impossible commerce experiences into reality with the flexibility of open SaaS.</p>
                </div>
                <div>
                    <article class="prose-xl mt-4 text-gray-600 leading-snug font-bold">
                    “"BigCommerce is a reliable platform; since launching, we haven't had to do much maintenance, which frees up time to make improvements to our online store.”
                </article>
                </div>
                <p class="mt-4 font-signika"><b>Emmy britt:</b> CEO founder mintech</p>
            </div>    
            </div>
          </div>
      </div>
      <!-- Build section ends here -->
      <!-- Features section starts here -->
      <div style="" class="bg-white px-[6rem] py-12">
         <div class="grid grid-cols-4 gap-3">
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/design.png" class="h-12 w-12" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Stay Agile</h1>
                     <p class="text-gray-600">Seize market opportunities and unleash new experiences at the speed of your business.</p>
                 </div>
             </div>
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/padlock.png" class="h-[3.4rem] w-[3.4rem]" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Go Headless</h1>
                     <p class="text-gray-600">Craft content-rich experiences anywhere your audience takes you.</p>
                 </div>
             </div>
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/metre.png" class="h-[3.4rem] w-[3.4rem]" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Integrate Anything</h1>
                     <p class="text-gray-600">Make unifying your backend or powering up with third-party apps a breeze.</p>
                 </div>
             </div>
             <div class="flex flex-col">
                 <div class="mb-3">
                     <img src="../../assets/icons/sonu.png" class="h-[3.4rem] w-[3.4rem]" alt="">
                 </div>
                 <div>
                     <h1 class="text-xl font-medium mb-3">Feature-Rich Platform</h1>
                     <p class="text-gray-600">How Burrow chose BigCommerce for customization and flexible feature integrations.</p>
                 </div>
             </div>
            </div>
      </div>
      </div>
      <!-- Another section ends here -->
      <div class="bg-gradient-to-br curve-div from-slate-900 via-slate-900 to-slate-900 py-20">
          <div class="text-white flex flex-col justify-center px-16">
              <div class="">
                <h1 class="text-5xl font-signika font-bold text-center">Sell More Everywhere</h1>
                <p class="text-xl mt-3 text-center w-[60rem]">Seamlessly list, optimize, advertise, sell and fulfill products across 100+ channels including Google, Facebook, 
                Instagram, TikTok, Pinterest, Snap, Amazon, eBay, Walmart, and Target.</p>
              </div>
              <div class="flex flex-end justify-center mt-4">
                  <a href="#">
                    <div class="flex group justify-center space-x-1 items-center">
                    <div class="text-xl group-hover:text-purple-500 text-purple-300">Learn more</div>
                    <div class="group-hover:animate-fade-side-right">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                    </div>
                </div>  
                  </a>
              </div>
          </div>
      </div>
      <div class="bg-white md:px-24 py-8 mb-4">
          <h1 class="text-center text-3xl font-bold font-signika text-gray-700">How different people use GoShopping</h1>
          <div class="flex justify-center items-center mt-12 px-8">
              <img src="../../assets/icons/differentpeople.png" alt="" class="h-[15rem] w-[45rem]">
          </div>
          <div class="my-6 grid grid-cols-3 gap-2">
              <div>
                  <h1 class="text-2xl font-bold text-purple-600 mb-2">Developers</h1>
                  <ul class="space-y-3">
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Experiment with the email sending functionality</span>
                          </div>
                      </li>
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Cover code with tests to run automated checks via content API</span>
                          </div>
                      </li>
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Verify different email aspects, debug sending script and HTML template</span>
                          </div>
                      </li>
                  </ul>
              </div>
              <div>
                  <h1 class="text-2xl font-bold text-purple-600 mb-2">Business individuals</h1>
                  <ul class="space-y-3">
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Experiment with the email sending functionality</span>
                          </div>
                      </li>
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Cover code with tests to run automated checks via content API</span>
                          </div>
                      </li>
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Verify different email aspects, debug sending script and HTML template</span>
                          </div>
                      </li>
                  </ul>
              </div>
              <div>
                  <h1 class="text-2xl font-bold text-purple-600 mb-2">Affiliate marketers</h1>
                  <ul class="space-y-3">
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Experiment with the email sending functionality</span>
                          </div>
                      </li>
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Cover code with tests to run automated checks via content API</span>
                          </div>
                      </li>
                      <li>
                          <div class="flex items-center">
                               <span class="las la-tint text-purple-600"></span> <span class="text-sm ml-1">Verify different email aspects, debug sending script and HTML template</span>
                          </div>
                      </li>
                  </ul>
              </div>
          </div>
          <div class="flex justify-evenly">
              <a href="" class="">
                  <div class="flex bg-purple-800  px-4 py-3 rounded-md text-white space-x-2">
                  <span>
                      <a href="">Join community of developers</a>
                  </span>
                  <span>
                      <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-purple-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                        </svg>
                  </span>
              </div>
              </a>
              <a href="">
                  <div class="flex bg-blue-800  px-4 py-3 rounded-md text-white space-x-2">
                  <span>
                      <router-link :to="{name: 'Affiliates'}">Become an Affiliate marketer</router-link>
                  </span>
                  <span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-blue-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14" />
                    </svg>
                  </span>
              </div>
              </a>
              <a href="">
                  <div class="flex bg-slate-800  px-4 py-3 rounded-md text-white space-x-2">
                  <span>
                      <a href="">Become a vendor</a>
                  </span>
                  <span>
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M16 15v-1a4 4 0 00-4-4H8m0 0l3 3m-3-3l3-3m9 14V5a2 2 0 00-2-2H6a2 2 0 00-2 2v16l4-2 4 2 4-2 4 2z" />
                    </svg>
                  </span>
              </div>
              </a>
          </div>
      </div>
      <!-- Another section here -->
      <div class="py-6">
          <h1 class="text-center text-3xl mb-6 font-bold font-signika text-gray-700">From our #BestClientEver</h1>
          <div class="w-[50rem] mx-auto relative">
              <div class="absolute cursor-pointer z-30 top-24 bg-white shadow-md rounded-lg py-1.5 px-1.5 -left-10">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
                </svg>
            </div>
              <div class="flex px-2 space-x-3 justify-between">
                  
              <div class="w-1/2 bg-white drop-shadow-lg px-6 py-7 rounded-xl">
                  <div>
                      <div class="flex items-center space-x-2 mb-2">
                          <h1 class="text-xl font-bold font-signika">Joshua Anderton</h1>
                      <span class="text-sm text-gray-600">@joshuaanderton</span>
                      </div>
                      
                      <p class="font-source">Just signed up for @GoShopping as an affiliate marketer and I’m loving it. So easy to set up. Provides so much peace
                           of mind. Ahh just love it.</p>
                           <p class="mt-[1rem]">{{ moment().format('MMMM Do YYYY, h:mm:ss a') }}</p>
                  </div>
              </div>
              <div class="w-1/2 bg-white drop-shadow-lg px-6 py-7 rounded-xl">
                  <div>
                      <div class="flex items-center space-x-2 mb-2">
                          <h1 class="text-xl font-bold font-signika">Douglar Santos</h1>
                      <span class="text-sm text-gray-600">@douglarsantos</span>
                      </div>
                      
                      <p class="font-source">After all these years of web development, how have I only JUST started 
                          using @goShpping. I had heard about it, but never got round to using it. An awesome way of 
                          testing emails.
.</p>
                           <p class="mt-[1rem]">{{ moment().format('MMMM Do YYYY, h:mm:ss a') }}</p>
                  </div>
              </div>
          </div>
          <div class="absolute z-30 cursor-pointer top-24 bg-white shadow-md rounded-lg py-1.5 px-1.5 -right-10">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />
                </svg>
            </div>
          </div>
          
      </div>
      <!-- Another section here -->
      <div class="bg-white px-8 py-8">
          <div>
              <h1 class="text-center text-3xl font-signika font-bold text-gray-700">Trusted by over 680,000 devs, vendors, and affiliates worldwide</h1>
          </div>
          <div class="flex justify-evenly">
              <div>
                  <img src="../../assets/icons/xpert.png" alt="" class="h-[6rem] grayscale blur-[0.79px] w-[6rem]">
              </div>
              <div>
                  <img src="../../assets/icons/exilarate.jpg" alt="" class="h-[6rem] grayscale blur-[0.79px] w-[6rem]">
              </div>
              <div>
                  <img src="../../assets/icons/mobileiron.png" alt="" class="h-[6rem] grayscale blur-[0.79px] w-[6rem]">
              </div>
              <div>
                  <img src="../../assets/icons/ksm.jpg" alt="" class="h-[6rem] grayscale blur-[0.79px] w-[6rem]">
              </div>
              <div>
                  <img src="../../assets/icons/agile.jpg" alt="" class="h-[6rem] grayscale blur-[0.79px] w-[6rem]">
              </div>
          </div>
      </div>
      <div class="bg-gray-50 font-bold text-gray-700 py-12 px-6">
          <h1 class="text-3xl font-signika mb-2">Resources and blogs</h1>
          <div class="grid grid-cols-3 gap-3">
             <div class="bg-slate-800 px-4 py-3">
                 <h1 class="text-white text-xl mb-3">Article</h1>
                 <h2 class="text-slate-50 mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</h2>
                 <p class="text-slate-200 text-sm leading-snug">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, enim consequuntur cupiditate 
                     eligendi fugiat error pariatur doloribus excepturi blanditiis 
                     sint optio, tenetur, modi veritatis. Qui odio architecto ratione cupiditate perferendis?</p>
                     <div class="flex group space-x-1 text-purple-500 items-center mt-3">
                         <div class="text-purple-200 group-hover:text-purple-500">Read now</div>
                         <div>
                             <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                         </div>
                     </div>
            </div> 
             <div class="bg-slate-800 px-4 py-3">
                 <h1 class="text-white text-xl mb-3">Article</h1>
                 <h2 class="text-slate-50 mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</h2>
                 <p class="text-slate-200 text-sm leading-snug">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, enim consequuntur cupiditate 
                     eligendi fugiat error pariatur doloribus excepturi blanditiis 
                     sint optio, tenetur, modi veritatis. Qui odio architecto ratione cupiditate perferendis?</p>
                     <div class="flex group space-x-1 text-purple-500 items-center mt-3">
                         <div class="text-purple-200 group-hover:text-purple-500">Read now</div>
                         <div>
                             <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                         </div>
                     </div>
            </div> 
             <div class="bg-slate-800 px-4 py-3">
                <h1 class="text-white text-xl mb-3">Article</h1>
                 <h2 class="text-slate-50 mb-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</h2>
                 <p class="text-slate-200 text-sm leading-snug">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, enim consequuntur cupiditate 
                     eligendi fugiat error pariatur doloribus excepturi blanditiis 
                     sint optio, tenetur, modi veritatis. Qui odio architecto ratione cupiditate perferendis?</p>
                     <div class="flex group space-x-1 text-purple-500 items-center mt-3">
                         <div class="text-purple-200 group-hover:text-purple-500">Read now</div>
                         <div>
                             <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                         </div>
                     </div>                 
            </div> 
          </div>
      </div>
      <SubScribeToNewsLetter />
  </div>
</template>

<script setup>
import moment from 'moment'
import SubScribeToNewsLetter from '../../components/SubScribeToNewsLetter.vue'

</script>

<style scoped>




</style>