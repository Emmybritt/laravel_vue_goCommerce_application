<template>
  <div class="px-6 py-4 divide-y space-y-3">
    <div>
      <h1 class="text-gray-700 font-bold tracking-wider uppercase">Profile</h1>
      <div>
        <p class="md:text-sm text-xs text-gray-700 my-2">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
         Ipsum quasi at quas ut architecto, itaque voluptatum ipsa animi 
         aperiam dolorum fugit similique atque debitis ab quidem sit rem deserunt fugiat?
        </p>
      </div>
      <div>
        <p class="md:text-sm text-xs text-gray-700 my-2">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
         Ipsum quasi at quas ut architecto, itaque voluptatum ipsa animi 
         aperiam dolorum fugit similique atque debitis ab quidem sit rem deserunt fugiat?
         Ipsum quasi at quas ut architecto, itaque voluptatum ipsa animi 
         aperiam dolorum fugit similique atque debitis ab quidem sit rem deserunt fugiat?
        </p>
        
      </div>
    </div>
    <div>
      <h1 class="mt-4 text-gray-700 font-xl font-bold tracking-wider uppercase mb-3">Experience</h1>
      <div>
        <div class="flex justify-between">
          <div class="flex flex-col w-1/3">
            <h1 class="text-sm text-gray-700 font-medium">2019 - 2021</h1>
            <h1 class="text-xs text-gray-700 font-medium uppercase">Magic brain academy</h1>
          </div>
          <div class="flex flex-col ml-4">
            <h1 class="text-sm text-cyan-500 font-medium uppercase">Senior front developer</h1>
            <p class="text-sm">Ipsum quasi at quas ut architecto, itaque voluptatum ipsa animi 
         aperiam dolorum fugit similique atque debitis ab quidem sit rem deserunt fugiat?</p>
          </div>
        </div>
        <div class="flex justify-between mt-3">
          <div class="flex flex-col w-1/3">
            <h1 class="text-sm text-gray-700 font-medium">2022 - 2022</h1>
            <h1 class="text-xs text-gray-700 font-medium uppercase leading-relaxed">Eagle wealth micro finance</h1>
          </div>
          <div class="flex flex-col ml-4">
            <h1 class="text-sm text-cyan-500 font-medium uppercase leading-relaxed">Senior full-stack developer</h1>
            <p class="text-sm">Ipsum quasi at quas ut architecto, itaque voluptatum ipsa animi 
         aperiam dolorum fugit similique atque debitis ab quidem sit rem deserunt fugiat?</p>
          </div>
        </div>
      </div>
    </div>
      <div class="w-full">
      <h1 class="mt-4 text-gray-700 font-xl font-bold tracking-wider uppercase mb-5">Professional skills</h1>
      <div>
        <div class="flex items-center">
          <div class="flex">
            <h1 class="text-xs text-gray-700 font-medium">HTML</h1>
          </div>
          <div class="ml-4">
            <div class="bg-slate-300 overflow-hidden h-1.5 w-full">
                <span class="bg-pink-400 rounded px-[70px]"></span>
            </div>
          </div>
        </div>
        
      </div>
      <div>
        <div class="flex items-center">
          <div class="flex">
            <h1 class="text-xs text-gray-700 font-medium">CSS</h1>
          </div>
          <div class="ml-4">
            <div class="bg-slate-300 overflow-hidden h-1.5 w-full">
                <span class="bg-pink-400 rounded px-[70px]"></span>
            </div>
          </div>
        </div>
        
      </div>
    </div>
    <!-- Interest -->
    <div>
      <h1 class="mt-4 text-gray-700 font-xl font-bold tracking-wider uppercase mb-1">Interest</h1>
      <div class="text-gray-600 ">
        <div class="flex items-center justify-evenly">
          <div class="flex items-center">
            <span class="text-blue-600 mr-2 las la-ball"></span>
            <p class="text-sm">Gaming</p>
          </div>
          <div class="flex items-center">
            <span class="text-blue-600 mr-2 lar la-piano"></span>
            <p class="text-sm">Playing piano</p>
          </div>
          <div class="flex items-center">
            <span class="text-blue-600 mr-2 las la-book"></span>
            <p class="text-sm">Reading</p>
          </div>
          <div class="flex items-center">
            <span class="text-blue-600 mr-2 las la-computer"></span>
            <p class="text-sm">Coding</p>
          </div>
        </div>
        
      </div>
    </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>