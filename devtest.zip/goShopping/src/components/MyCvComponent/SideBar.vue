<template>
  <div>
      <div class="mx-auto">
          <img class="block mx-auto border-cyan-200 border-4 w-auto h-[7rem] rounded-full sm:shrink-0" src="../../assets/mypics.jpg" alt="">
      </div>
      <div class="flex border-b border-slate-400 py-2 flex-col items-center justify-center">
          <h1 class="text-gray-100 font-bold text-2xl tracking-wide mt-2">Emmy britt</h1>
          <p class="text-gray-200 uppercase text-sm font-normal leading-relaxed">Software engineer</p>
      </div>
      <div class="mt-6">
          <h1 class="text-white md:text-sm text-lg my-3 tracking-widest uppercase font-bold">Contact info</h1>
          <div class="space-y-2">
              <div class="flex items-center">
                  <span class="las la-phone text-lg text-cyan-300"></span>
                  <p class="text-sm ml-2 font-thin text-slate-200">+234 701 6588 973</p>
              </div>
              <div class="flex items-center">
                  <span class="las la-inbox text-lg text-cyan-300 "></span>
                  <p class="text-sm ml-2 font-thin text-slate-200">beritogwu@gmail.com</p>
              </div>
              <div class="flex items-center">
                  <span class="lab la-google text-lg text-cyan-300"></span>
                  <p class="text-sm ml-2 font-thin text-slate-200">www.infoternet.com</p>
              </div>
              <div class="flex items-center">
                  <span class="lab la-linkedin text-cyan-300 text-lg"></span>
                  <p class="text-sm ml-2 font-thin text-slate-200">www.linkedin.com/emmybritt</p>
              </div>
          </div>
      </div>
      <div class="mt-6">
          <h1 class="text-white text-sm uppercase tracking-widest font-medium mb-3">Education</h1>
          <div>
              <div class="flex flex-col">
                  <span class="text-cyan-300 text-sm">2018 - 2021</span>
                  <h1 class="text-sm my-0.5">Bachelor Degree in computer science</h1>
                  <span class="text-sm my-0.5">Adeniran ogunsanya college of education</span>
              </div>
          </div>
      </div>
      <div class="mt-6">
          <h1 class="text-white text-sm uppercase font-medium mb-3">Languages</h1>
          <div>
              <div class="flex flex-col">
                  <div>
                      <span class="text-sm">English</span>
                      <div class="bg-slate-400 rounded overflow-hidden h-1.5 w-full">
                          <span class="bg-cyan-400 px-[66%]"></span>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>