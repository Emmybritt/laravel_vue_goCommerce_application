<template>
  <div class="hidden bg-white flex px-[6rem] py-2 drop-shadow-md ">
      <div class="w-[12rem]">
        <h1 >
          go<span class="text-indigo-600">Shopping</span>
        </h1>
           
      </div>
      <div class="flex-auto">
          <div>
            <div class="flex">
              <h1 class="font-medium text-gray-600 font-signika">Home</h1>
            </div>
          </div>
      </div>
  </div>
</template>

<script setup>

</script>

<style>

</style>