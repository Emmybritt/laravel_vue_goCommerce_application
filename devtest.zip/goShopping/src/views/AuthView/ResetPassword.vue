<template>
  <div>
      This is the Reset password
  </div>
</template>

<script setup>

</script>

<style>

</style>