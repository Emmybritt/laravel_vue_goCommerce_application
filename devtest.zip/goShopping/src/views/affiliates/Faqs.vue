<template>
  <div class="font-source">
      <div class="bg-blue-800 flex items-center justify-center h-30 py-12">
          <h1 class="text-4xl text-white font-signika font-bold">Frequently Asked Questions</h1>
      </div>
      <div class="bg-white h-[20rem] py-16">
          This are the faqs here
      </div>
  </div>
</template>

<script setup>
import {useTitle} from '@vueuse/core'
const title = useTitle('Frequently asked questions', { titleTemplate: '%s | Earn money with the goShopping Affiliate Program by PROMOTING HIGH QUALITY PRODUCTS' });

</script>

<style>

</style>