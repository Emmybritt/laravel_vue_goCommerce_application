<template>
    <div class="antialised text-gray-600">
        <div class="absolute w-full min-h-screen">
            <div class="h-1/2 bg-cover bg-bottom"></div>
        </div>
        <section class="flex justify-center items-center">
            <div class="relative">
            <div class="absolute z-0 inset-0 bg-gradient-to-r from-cyan-400 to-emerald-400 shadow-md transform -skew-6 -rotate-6 rounded-md"></div>
        <div class="bg-white relative md:flex space-x-12 z-10 p-12 rounded-md shadow-md">
            <div class="py-4 flex flex-col space-y-4">
                <div>
                    <p class="text-lg">Hello I am</p>
                    <h1 class="text-5xl font-bold text-gray-800">Emmy britt</h1>
                </div>
                <p class="text-xl pt-3 leading-relaxed">Full-stack web developer who crafts beautifull websites that help yuor business grow online</p>
                <div class="inline-flex space-x-4 text-xl">
                    <i class="lab la-youtube"></i>
                    <i class="lab la-linkedin"></i>
                    <i class="lab la-twitter"></i>
                    <i class="lab la-github"></i>
                </div>
            </div>
            <img src="../../assets/mypics.jpg" alt="emmy britt" class="w-80 h-80 shadow-md flex-shrink-0 rounded-full border-6 border-white">
        </div>
        </div>
        </section>
        
    </div>
</template>
<script>

</script>