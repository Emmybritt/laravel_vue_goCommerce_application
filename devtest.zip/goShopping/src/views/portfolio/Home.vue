<template>
    <div class="grid grid-cols-12 gap-6 lg:px-48 bg-gradient-to-r from-green to-blue-400 px-5 sm:px-20 md:px-32 py-14">
        <div class="lg:col-span-3 p-4 text-center col-span-12 bg-white rounded-2xl">
            <Home></Home>
        </div>
        <div class="lg:col-span-9 col-span-12 bg-white rounded-2xl">wnewkenk</div>
    </div>
</template>
<script setup>
import Home from '../../components/portfoliocomponent/Sidebar.vue'

</script>